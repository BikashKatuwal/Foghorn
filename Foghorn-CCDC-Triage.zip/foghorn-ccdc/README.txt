FOGHORN CCDC TRIAGE (PRACTICE / only if organizer permits)

1. Copy ccdc-triage.sh to your Rocky Linux machine.
2. chmod +x ccdc-triage.sh
3. sudo ./ccdc-triage.sh all
   Or use: network | services | accounts | persistence | security | apps | logs
4. Reports saved to ~/foghorn-triage-YYYYMMDD-HHMMSS/ (when run with sudo, under root's home).

All checks are read-only; some may fail if optional tools are absent.
Do not run against real competition machines unless permitted by rules/organizers.
Never upload raw evidence publicly; inspect for secrets first.
Do not disable firewall, SELinux, SSH or scored apps without verifying dependencies.

Packet says: Foghorn (.13) = Rocky Linux Wiki/Chat; exact applications unknown.
Scored checks every 2-4 minutes, SLA after five failed checks.
AI-generated inject submissions prohibited. Ask organizers if AI-assisted scripts are allowed.
