#!/usr/bin/env bash
# CCDC Foghorn: read-only inventory. No changes to services or firewall.
set -u
export LC_ALL=C
MODE="${1:-all}"
case "$MODE" in all|network|services|accounts|persistence|security|logs|apps) ;; *) echo "Usage: $0 [all|network|services|accounts|persistence|security|logs|apps]"; exit 2;; esac
OUT="${HOME}/foghorn-triage-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUT" || exit 1
run() { local file="$1"; shift; { printf '$'; printf ' %q' "$@"; printf '\n\n'; "$@"; } >"$OUT/$file.txt" 2>&1 || true; }
section() { [[ "$MODE" == all || "$MODE" == "$1" ]]; }
run identity hostnamectl
run os-release cat /etc/os-release
if section network; then
 run addresses ip -br addr; run routing ip route; run listeners ss -tulpn; run connections ss -tunap; run dns resolvectl status
fi
if section services; then
 run running-services systemctl list-units --type=service --state=running --no-pager
 run enabled-services systemctl list-unit-files --type=service --state=enabled --no-pager
 run processes ps auxww
fi
if section accounts; then
 run accounts getent passwd; run wheel-members getent group wheel; run active-sessions who -a
 run recent-logins last -n 30
 run sudo-policy sudo -n grep -R -nE '^[[:space:]]*[^#[:space:]]' /etc/sudoers /etc/sudoers.d
 run ssh-config sudo -n sshd -T
fi
if section persistence; then
 run timers systemctl list-timers --all --no-pager
 run crontab sudo -n crontab -l
 run cron-directories sudo -n ls -la /etc/cron.d /etc/cron.daily /etc/cron.hourly /var/spool/cron
 run unit-files sudo -n find /etc/systemd/system -maxdepth 3 -type f -print
 run ssh-authorized-key-paths sudo -n find /home /root -maxdepth 3 -name authorized_keys -print
fi
if section security; then
 run firewall sudo -n firewall-cmd --list-all-zones
 run selinux getenforce
 run sshd-service systemctl status sshd --no-pager
 run updates dnf check-update --cacheonly
fi
if section apps; then
 run web-roots sudo -n ls -la /var/www /opt /srv
 run web-config sudo -n httpd -S
 run installed-apps rpm -qa
 run podman sudo -n podman ps -a
 run docker sudo -n docker ps -a
fi
if section logs; then
 run ssh-logs sudo -n journalctl -u sshd --since '2 hours ago' --no-pager -n 200
 run errors sudo -n journalctl -p warning --since '2 hours ago' --no-pager -n 200
 run web-errors sudo -n tail -n 100 /var/log/httpd/error_log
fi
printf 'Saved reports in: %s\n' "$OUT"
printf 'Review before sharing: outputs may include IPs, usernames, command arguments and secrets.\n'
